# laravel2020-D-G6
laravel2020 class D Group 6. Data Dosen.

Reza, Nadia, Heni, Anggit.
